const Dialog = ({ children }) => {
	return <dialog>{children}</dialog>;
};
export default Dialog;
