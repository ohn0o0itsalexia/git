// insert router here
import(`./pages/${page}`);
