export var value = 0;
export function increment() {
	value++;
}
export default "MyLibrary";
