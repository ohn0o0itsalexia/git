// some module
import("./async1");
import("./async2");
