# example.js

```javascript
_{{example.js}}_
```

# style.css

```javascript
_{{style.css}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/output.css

```javascript
_{{dist/output.css}}_
```

## production

```javascript
_{{production:dist/output.css}}_
```

# dist/1.output.css

```javascript
_{{dist/1.output.css}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
