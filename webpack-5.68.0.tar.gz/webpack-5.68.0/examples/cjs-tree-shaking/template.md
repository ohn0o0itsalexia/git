# example.js

```javascript
_{{example.js}}_
```

# increment.js

```javascript
_{{increment.js}}_
```

# math.js

```javascript
_{{math.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/output.js (production)

```javascript
_{{production:dist/output.js}}_
```

# dist/without.js (same without tree shaking)

```javascript
_{{production:dist/without.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
